package com.dxc.pms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.dxc.pms.dao.ProductDAO;
import com.dxc.pms.model.Product;
import com.dxc.pms.service.ProductService;

@RestController
@RequestMapping("/product")
@CrossOrigin(origins= {"http://localhost:3000","http://localhost:4200"})
public class productController {
	@Autowired
	ProductService productService;
	//getting a single product
	@GetMapping("/{productId}")
	
	public ResponseEntity<Product> getProduct(@PathVariable("productId")int productId) {
		System.out.println("Get 1 called"+productId);
		Product product = new Product();
		if(productService.isProductExists(productId))
		{
			product= productService.getProduct(productId);
			return new ResponseEntity<Product>(product,HttpStatus.OK);
		}
		else {
			return new ResponseEntity<Product>(product,HttpStatus.NO_CONTENT);
		}
		
	}
	//deleting product
	@DeleteMapping("/{productId}")
	
	public ResponseEntity<Product> deleteProduct(@PathVariable("productId")int productId) {
		System.out.println("deleting called"+productId);
		
		if(productService.isProductExists(productId))
		{
			productService.deleteProduct(productId);
			return new ResponseEntity<Product>(HttpStatus.NO_CONTENT);
		}
		else {
			return new ResponseEntity<Product>(HttpStatus.NOT_FOUND);
		}
		
	}
	//get all products
		@GetMapping
		public ResponseEntity<List<Product>> getAllProducts() {
			System.out.println("Fetching all products");
			List<Product> allProducts=productService.getProducts();
			return new ResponseEntity<List<Product>>(allProducts,HttpStatus.OK);
		}
		//add product
				@PostMapping
				public ResponseEntity<Product> addProduct(@RequestBody Product product) {
					System.out.println(product);
					if(productService.isProductExists(product.getProductId()))
					{
						return new ResponseEntity<Product>(product,HttpStatus.CONFLICT);
					}
					else
					{
						productService.addProduct(product);
						return new ResponseEntity<Product>(product,HttpStatus.CREATED);
					}
					
				}
				//update product
				@PutMapping
				public ResponseEntity<Product> updateProduct(@RequestBody Product product) {
					System.out.println(product);
		
					if(productService.isProductExists(product.getProductId()))
					{
						productService.updateProduct(product);
						return new ResponseEntity<Product>(product,HttpStatus.OK);
					}
					else {
						return new ResponseEntity<Product>(product,HttpStatus.NO_CONTENT);
					}
				}	
			/*	@GetMapping("/{productName}")
				public List<Product> searchProduct(@PathVariable("productName")String productName) {
					return productService.searchProductByName(productName);
				}*/
	//demo
	@RequestMapping("/getProduct/{productId}/{oId}")
	public Product getProduct2(@PathVariable("productId")int productId,@PathVariable("oId")int oId) {
		System.out.println("Get 1 called productId: "+productId+" orderId: "+oId);
		return productService.getProduct(productId);
	}
	//demo
	@RequestMapping("/getProduct/pp")
	public Product getProduct() {
		System.out.println("pp called");
		return productService.getProduct(1234);
	}
	/*
	 * @RequestMapping("/productSave") public ModelAndView productForm(Product
	 * product) { System.out.println("Inside controller"+product);
	 * productService.addProduct(product); return new
	 * ModelAndView("success","product",product); }
	 */
}
